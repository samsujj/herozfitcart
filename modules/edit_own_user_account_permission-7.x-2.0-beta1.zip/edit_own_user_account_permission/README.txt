Provides a permission to control whether or not users can edit their own
account.

If the user does not have the "Edit own user account" permission, the "Edit"
local menu option on the user's profile will be hidden. If the user attempts to
edit their own profile by going to /user/%user/edit they will recieve an access
denied page.
